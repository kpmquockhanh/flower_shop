<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<link rel="shortcut icon" type="image/x-icon" href="{{asset('img/logo2.png')}}" />
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
<!--     Fonts and icons     -->
<link href="{{asset('backend/plugins/fontawesome/css/font-awesome.min.css')}}" rel="stylesheet">
<!-- CSS Files -->
<link href="{{asset('backend/css/bootstrap.min.css')}}" rel="stylesheet" />
<link href="{{asset('backend/css/iziToast.min.css')}}" rel="stylesheet" />
<link href="{{asset('backend/css/paper-dashboard.min.css')}}" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->
{{--<link href="{{asset('backend/demo/demo.css')}}" rel="stylesheet" />--}}
