<div class="brand-logo">
    <div class="container">
        <div class="slider-items-products">
            <div id="brand-logo-slider" class="product-flexslider hidden-buttons">
                <div class="slider-items slider-width-col6">

                    <!-- Item -->

                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo1.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo2.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo3.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo4.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo5.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo6.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo1.png')}}"
                                    alt=""> </a>
                    </div>
                    <div class="item">
                        <a href="" target="_blank"> <img
                                    src="{{asset('assets/uploads/sites/26/2016/02/b-logo2.png')}}"
                                    alt=""> </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>