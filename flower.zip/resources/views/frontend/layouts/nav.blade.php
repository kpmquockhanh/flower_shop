<nav>
    <div class="container">
        <div class="mm-toggle-wrap">
            <div class="mm-toggle">
                <a class="mobile-toggle">
                    <i class="fa fa-reorder"></i>
                </a>
            </div>
        </div>
        <div id="main-menu-new">
            <div class="nav-inner">
                <ul id="menu-mainmenu" class="main-menu mega-menu">
                    <li id="nav-menu-item-2127" class="homecustom menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children active has-sub narrow ">
                        <a href="/" class=" current ">
							<span>
								<i class="fa fa-home"></i>
							</span>
                        </a>
                        {{--

						<div class="mgk-popup">
							<div class="inner" style="">
								<ul class="sub-menu">
                                    --}}
                        {{--

									<li id="nav-menu-item-2040" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home active" data-cols="1">
										<a href="#" class="">
											<span>Home Layout 1</span>
										</a>
									</li>
                        --}}
                        {{--

									<li id="nav-menu-item-2039" class="menu-item menu-item-type-custom menu-item-object-custom " data-cols="1">
										<a href="#" class="">
											<span>Home Layout 2</span>
										</a>
									</li>
                        --}}
                        {{--

								</ul>
							</div>
						</div>
            --}}

                    </li>
                    <li id="nav-menu-item-2008" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  has-sub wide  col-6">
                        <a href="#" class="">
                            <span>Home</span>
                        </a>
                        <div class="mgk-popup">
                            <div class="inner" style="">
                                <ul class="sub-menu">
                                    <li id="nav-menu-item-2009" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Special</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2010" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Valentine Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2011" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Friendship Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2012" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Rose Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2013" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>New Year Flowers</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2023" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Upcoming</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2024" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Diwali</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2025" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Rakhi</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2026" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Christmas</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2027" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>New Year</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2014" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Everyday</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2015" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Birthday Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2016" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Anniversary Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2047" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Wedding Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2048" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower Bouquets</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2018" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Occasional Day</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2019" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Womens Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2020" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Fathers Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2021" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Teachers Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2022" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Mothers Day Flowers</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2056" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Favourite</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2057" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Roses Bouquet</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2058" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Lilies</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2059" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Orchids</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2060" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Tulips</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2061" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Combos</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2062" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Dry Fruit</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2063" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Card</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2064" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Teddy Bear</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2065" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Chocolates</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2054" class="women-img menu-item menu-item-type-custom menu-item-object-custom imgitem " data-cols="1" style="height:138px;width:577px;background-image:url({{asset('assets/uploads/sites/26/2016/02/menu-banner1.png')}});;background-position:center center;;background-repeat:no-repeat;;background-size:cover;"></li>
                                    <li id="nav-menu-item-2066" class="women-img menu-item menu-item-type-custom menu-item-object-custom imgitem " data-cols="1" style="height:138px;width:577px;background-image:url({{asset('assets/uploads/sites/26/2017/07/menu-banner2-1.png')}});;background-position:center center;;background-repeat:no-repeat;;background-size:cover;"></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li id="nav-menu-item-2002" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  has-sub wide  col-4">
                        <a href="#" class="">
                            <span>Fresh</span>
                        </a>
                        <div class="mgk-popup">
                            <div class="inner" style="">
                                <ul class="sub-menu">
                                    <li id="nav-menu-item-2003" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Flowers &#038; Combos</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2004" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Dry Fruit</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2028" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Card</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2029" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Teddy Bear</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2017" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Chocolates</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2005" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Flower with</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2006" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Get Well Soon</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2035" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Congratulations</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2007" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>I Am Sorry</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2036" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Good Luck</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2030" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Favourite Flowers</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2031" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Roses Bouquet</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2032" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Lilies</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2033" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Orchids</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2034" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Tulips</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2055" class="men-img menu-item menu-item-type-custom menu-item-object-custom imgitem " data-cols="1"
                                        style="background-image:url({{asset('assets/uploads/sites/26/2017/07/menu-img.jpg')}});background-position:center;background-repeat:no-repeat;background-size:cover;"></li>
                                    <li id="nav-menu-item-2069" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Mixed Flowers</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2070" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Precious Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2129" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flowers &#038; Combos</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2071" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower Bouquet</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2068" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower &#038; Card</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2049" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Everyday Occasions</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2050" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Wedding Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2051" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Anniversary Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2052" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Flower Bouquets</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2053" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Birthday Flowers</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2072" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Special Occasion</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2073" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Valentine Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2074" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Friendship Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2075" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>Rose Day Flowers</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2076" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat ">
                                                <a href="#" class="">
                                                    <span>New Year Flowers</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li id="nav-menu-item-2037" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat  narrow ">
                        <a href="#" class="">
                            <span>Birthday</span>
                        </a>
                    </li>
                    <li id="nav-menu-item-2117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has-sub narrow ">
                        <a href="#" class="">
                            <span>Special</span>
                        </a>
                        <div class="mgk-popup">
                            <div class="inner" style="">
                                <ul class="sub-menu">
                                    <li id="nav-menu-item-2330" class="menu-item menu-item-type-custom menu-item-object-custom " data-cols="1">
                                        <a href="#" class="">
                                            <span>Blog Left Sidebar</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2331" class="menu-item menu-item-type-custom menu-item-object-custom " data-cols="1">
                                        <a href="#" class="">
                                            <span>Blog Right Sidebar</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2332" class="menu-item menu-item-type-custom menu-item-object-custom " data-cols="1">
                                        <a href="#" class="">
                                            <span>Blog Full Width</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li id="nav-menu-item-2038" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has-sub narrow ">
                        <a href="#" class="">
                            <span>Wedding</span>
                        </a>
                        <div class="mgk-popup">
                            <div class="inner" style="">
                                <ul class="sub-menu">
                                    <li id="nav-menu-item-2326" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Contact Us</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2122" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Typography</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2120" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Full Width Page</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2123" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Page – Left Sidebar</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2121" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Page – Right Sidebar</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2124" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Page – 3 Column</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2278" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>FAQs Page</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2282" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>About Us</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2281" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Pricing Table</span>
                                        </a>
                                    </li>
                                    <li id="nav-menu-item-2279" class="menu-item menu-item-type-post_type menu-item-object-page " data-cols="1">
                                        <a href="#" class="">
                                            <span>Track Order</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li id="nav-menu-item-2327" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children  has-sub wide  col-4">
                        <a href="#" class="">
                            <span>Shop</span>
                        </a>
                        <div class="mgk-popup">
                            <div class="inner" style="">
                                <ul class="sub-menu">
                                    <li id="nav-menu-item-2283" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Product Layouts</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2166" class="menu-item menu-item-type-post_type menu-item-object-product ">
                                                <a href="#" class="">
                                                    <span>Single Product</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2167" class="menu-item menu-item-type-post_type menu-item-object-product ">
                                                <a href="#" class="">
                                                    <span>Variable Product</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2169" class="menu-item menu-item-type-post_type menu-item-object-product ">
                                                <a href="#" class="">
                                                    <span>Grouped Product</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2168" class="menu-item menu-item-type-post_type menu-item-object-product ">
                                                <a href="#" class="">
                                                    <span>External Product</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2288" class="menu-item menu-item-type-post_type menu-item-object-product ">
                                                <a href="#" class="">
                                                    <span>Hot Deal Product</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2284" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  sub" data-cols="1">
                                        <a href="#" class="">
                                            <span>Shop Layout</span>
                                        </a>
                                        <ul class="sub-menu">
                                            <li id="nav-menu-item-2285" class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                <a href="#" class="">
                                                    <span>Shop Left Sidebar</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2286" class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                <a href="#" class="">
                                                    <span>Shop Right Sidebar</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2287" class="menu-item menu-item-type-custom menu-item-object-custom ">
                                                <a href="#" class="">
                                                    <span>Shop Full Width</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2280" class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                <a href="#" class="">
                                                    <span>Product Category</span>
                                                </a>
                                            </li>
                                            <li id="nav-menu-item-2277" class="menu-item menu-item-type-post_type menu-item-object-page ">
                                                <a href="#" class="">
                                                    <span>Hot Deals</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li id="nav-menu-item-2289" class="women-img menu-item menu-item-type-custom menu-item-object-custom imgitem " data-cols="2" style="height:138px; margin-top:20px;background-image:url({{asset('assets/uploads/sites/26/2017/07/menu-banner2-1.png')}});;background-position:center center;;background-repeat:no-repeat;;background-size:cover;"></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>