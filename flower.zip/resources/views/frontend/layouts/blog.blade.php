<div class="container latest-blog">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="blog-outer-container">
                <div class="new_title">
                    <h2><strong> Latest </strong>Blog</h2>

                </div>

                <div class="blog-inner">



                    <div class="col-lg-6 col-md-6 col-sm-6 blog-preview_item">
                        <div class="entry-thumb image-hover2">
                            <a href="#">
                                <img src="{{asset('assets/uploads/sites/26/2016/01/blog-img2.jpg')}}" alt="Pellentesque habitant morbi">
                            </a>

                        </div>

                        <div class="blog-preview_info">
                            <ul class="post-meta">
                                <li><i class="fa fa-user"></i>By  MagikThemes </li>
                                <li><i class="fa fa-comment"></i><a href="#">5 Comments                          </a></li>
                                <li><i class="fa fa-calendar"></i><time class="entry-date" datetime="2015-05-11T11:19:34+00:00">January 04, 2016</time>
                                </li>
                            </ul>
                            <h4 class="blog-preview_title">
                                <a href="#">Pellentesque habitant morbi                     </a>
                            </h4>
                            <div class="blog-preview_desc"><div class="homeblog"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum et mi vulputate gen vehicula maximus sagittis rhoncus tortor. Class aptent taciti sociosqu ad litora torquent perconubia nostra, per inceptos himenaeos. Sed vel nisi orci. Pellentesque sed dignissim dolor, sit amet gravida orci. Suspendisse imperdiet ex vel lacus imperdiet mollis. Sed feugiat enim sed eros interdum, in ullamcorper erat pulvinar. Donec maximus lacus odio, in ullamcorper mauris congue scelerisque. Aliquam erat volutpat. Sed vel vestibulum nisl.</p>
                                </div></div>
                            <a class="blog-preview_btn" href="#">Read more</a>
                        </div>

                    </div>



                    <div class="col-lg-6 col-md-6 col-sm-6 blog-preview_item">
                        <div class="entry-thumb image-hover2">
                            <a href="#">
                                <img src="{{asset('assets/uploads/sites/26/2016/01/blog-img1-1.jpg')}}" alt="Standard blog post with photo">
                            </a>

                        </div>

                        <div class="blog-preview_info">
                            <ul class="post-meta">
                                <li><i class="fa fa-user"></i>By  MagikThemes </li>
                                <li><i class="fa fa-comment"></i><a href="#">4 Comments                          </a></li>
                                <li><i class="fa fa-calendar"></i><time class="entry-date" datetime="2015-05-11T11:19:34+00:00">December 02, 2015</time>
                                </li>
                            </ul>
                            <h4 class="blog-preview_title">
                                <a href="#">Standard blog post with photo                     </a>
                            </h4>
                            <div class="blog-preview_desc"><div class="homeblog"><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec mollis. Quis quefgh convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravidaid. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna. Praesent sit amet ligula id orci venenatis auctor. Phasellus porttitor, metus non tincidunt dapibus, orci pede pretium neque, sit amet adipiscing ipsum lectus et libero. Aenean bibendum. Curabitur mattis quam id urna. Vivamus dui.</p>
                                </div></div>
                            <a class="blog-preview_btn" href="#">Read more</a>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>