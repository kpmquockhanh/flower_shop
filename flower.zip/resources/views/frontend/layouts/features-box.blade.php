<div class="our-features-box">
    <div class="container">

        <div class="row">
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box first"> <span class="fa fa-truck"></span>
                    <div class="content">
                        <h3>FREE SHIPPING WORLDWIDE</h3>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"> <span class="fa fa-headphones"></span>
                    <div class="content">
                        <h3>24X7 CUSTOMER SUPPORT</h3>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"> <span class="fa fa-share"></span>
                    <div class="content">
                        <h3>RETURNS AND EXCHANGE</h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box last"> <span class="fa fa-phone"></span>
                    <div class="content">
                        <h3>Hotline  +(408) 394-7557</h3>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>