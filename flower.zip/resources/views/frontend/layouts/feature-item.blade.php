<div class="featured-pro">
    <div class="container">
        <div class="slider-items-products">
            <div class="featured-block">
                <div id="featured-slider" class="product-flexslider hidden-buttons">
                    <div class="home-block-inner">
                        <div class="block-title">
                            <h2>Featured<br>
                                <em> Products</em>
                            </h2>

                        </div>
                        <div class="pretext">

                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Curabitur eu odio non justo euismod congue ut nec orci.                </div>
                        <a class="view_more_bnt" href="#">VIEW ALL </a>
                    </div>

                    <div class="slider-items slider-width-col4 products-grid block-content owl-carousel owl-theme">



                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Round Handle Basket of Mixed Roses" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Round Handle Basket of Mixed Roses" src="{{asset('assets/uploads/sites/26/2017/07/product5-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="new-label new-top-right">
                                            Sale            </div>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="24">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=24"  data-product-id="24"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="24"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Round Handle Basket of Mixed Roses"> Round Handle Basket of Mixed Roses </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:0%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="24"><span class="woocs_price_code" data-product-id="24"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>39.99</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>37.00</span></ins></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="24"
                                                   href='/creta/?add-to-cart=24'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Pink Roses for your Loved Ones" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Pink Roses for your Loved Ones" src="{{asset('assets/uploads/sites/26/2017/07/product10-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="96">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=96"  data-product-id="96"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="96"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Pink Roses for your Loved Ones"> Pink Roses for your Loved Ones </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:100%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="96"><span class="woocs_price_code" data-product-id="96"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>19.99</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="96"
                                                   href='/creta/?add-to-cart=96'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Beautiful Basket of Gerberas & Roses" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Beautiful Basket of Gerberas & Roses" src="{{asset('assets/uploads/sites/26/2017/07/product11-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="87">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=87"  data-product-id="87"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="87"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Beautiful Basket of Gerberas & Roses"> Beautiful Basket of Gerberas & Roses </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:80%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="87"><span class="woocs_price_code" data-product-id="87"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>11.99</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="87"
                                                   href='/creta/?add-to-cart=87'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Bunch of Pink & Red Roses in a Glass Vase" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Bunch of Pink & Red Roses in a Glass Vase" src="{{asset('assets/uploads/sites/26/2017/07/product14-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="104">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=104"  data-product-id="104"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="104"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Bunch of Pink & Red Roses in a Glass Vase"> Bunch of Pink & Red Roses in a Glass Vase </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:100%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="104"><span class="woocs_price_code" data-product-id="104"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="104"
                                                   href='/creta/?add-to-cart=104'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Bunch of Charming Pink Roses" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Bunch of Charming Pink Roses" src="{{asset('assets/uploads/sites/26/2017/07/product17-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="19">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=19"  data-product-id="19"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="19"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Bunch of Charming Pink Roses"> Bunch of Charming Pink Roses </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:90%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="19"><span class="woocs_price_code" data-product-id="19"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="19"
                                                   href='/creta/?add-to-cart=19'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Glass Vase of Mix Flowers For Mother" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Glass Vase of Mix Flowers For Mother" src="{{asset('assets/uploads/sites/26/2017/07/product18-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="new-label new-top-right">
                                            Sale            </div>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="102">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=102"  data-product-id="102"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="102"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Glass Vase of Mix Flowers For Mother"> Glass Vase of Mix Flowers For Mother </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:80%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="102"><span class="woocs_price_code" data-product-id="102"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>18.00</span></ins></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="102"
                                                   href='/creta/?add-to-cart=102'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>

    </div>

</div>