<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AddressDeliveryController extends Controller
{
    //
}
