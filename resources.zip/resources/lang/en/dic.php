<?php

return [

    'hello' => 'Hi :name',
];
