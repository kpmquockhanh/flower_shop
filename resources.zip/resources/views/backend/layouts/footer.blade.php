<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
        <div class="row">
            <nav class="footer-nav">
                <ul>
                    <li>
                        <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a>
                    </li>
                    <li>
                        <a href="http://blog.creative-tim.com/" target="_blank">Blog</a>
                    </li>
                    <li>
                        <a href="https://www.creative-tim.com/license" target="_blank">Licenses</a>
                    </li>
                </ul>
</nav>
            <div class="credits ml-auto">
              <span class="copyright">
                ©
                <script>
                  document.write(new Date().getFullYear())
                </script>, made with <i class="fa fa-heart heart"></i> by Nhóm 2 KTPM1 K10 HaUI
              </span>
            </div>
        </div>
    </div>
</footer>
<script src="{{asset('backend/js/core/jquery.min.js')}}"></script>
<script src="{{asset('backend/js/core/popper.min.js')}}"></script>
<script src="{{asset('backend/js/core/bootstrap.min.js')}}"></script>
<script src="{{asset('backend/js/plugins/perfect-scrollbar.jquery.min.js')}}"></script>
<script src="{{asset('backend/js/plugins/moment.min.js')}}"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
{{--<script src="{{asset('backend/js/plugins/bootstrap-switch.js')}}"></script>--}}
<!--  Plugin for Sweet Alert -->
{{--<script src="{{asset('backend/js/plugins/sweetalert2.min.js')}}"></script>--}}
<!-- Forms Validations Plugin -->
{{--<script src="{{asset('backend/js/plugins/jquery.validate.min.js')}}"></script>--}}
<!--  Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
{{--<script src="{{asset('backend/js/plugins/jquery.bootstrap-wizard.js')}}"></script>--}}
<!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
<script src="{{asset('backend/js/plugins/bootstrap-selectpicker.js')}}"></script>
<!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
{{--<script src="{{asset('backend/js/plugins/bootstrap-datetimepicker.js')}}"></script>--}}
<!--  DataTables.net Plugin, full documentation here: https://datatables.net/    -->
{{--<script src="{{asset('backend/js/plugins/jquery.dataTables.min.js')}}"></script>--}}
<!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
{{--<script src="{{asset('backend/js/plugins/bootstrap-tagsinput.js')}}"></script>--}}
<!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="{{asset('backend/js/plugins/jasny-bootstrap.min.js')}}"></script>
<!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
{{--<script src="{{asset('backend/js/plugins/fullcalendar.min.js')}}"></script>--}}
<!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
{{--<script src="{{asset('backend/js/plugins/jquery-jvectormap.js')}}"></script>--}}
<!--  Plugin for the Bootstrap Table -->
{{--<script src="{{asset('backend/js/plugins/nouislider.min.js')}}"></script>--}}
<!--  Google Maps Plugin    -->
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="{{asset('backend/plugins/buttons.js')}}"></script>
<!-- Chart JS -->
{{--<script src="{{asset('backend/js/plugins/chartjs.min.js')}}"></script>--}}
<!--  Notifications Plugin    -->
{{--<script src="{{asset('backend/js/plugins/bootstrap-notify.js')}}"></script>--}}
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="{{asset('backend/js/paper-dashboard.min.js')}}" type="text/javascript"></script>
<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
{{--<script src="{{asset('backend/demo/demo.css')}}"></script>--}}
<!-- Sharrre libray -->
{{--<script src="{{asset('backend/demo/jquery.sharrre.js')}}"></script>--}}
<script src="{{asset('backend/js/plugins/axios.min.js')}}"></script>
<script src="{{asset('backend/js/plugins/iziToast.min.js')}}"></script>
<script src="{{asset('backend/js/admin.js')}}"></script>



