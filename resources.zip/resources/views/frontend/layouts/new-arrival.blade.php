<div class="new-arrivals-pro">
    <div class="container">
        <div class="slider-items-products">
            <div class="new-arrivals-block">
                <div id="new-arrivals-slider" class="product-flexslider hidden-buttons">
                    <div class="home-block-inner">
                        <div class="block-title">
                            <h2>Special<br>
                                <em> Products</em>
                            </h2>

                        </div>
                        <div class="pretext">

                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Curabitur eu odio non justo euismod congue ut nec orci.                        </div>
                        <a class="view_more_bnt" href="#">VIEW ALL </a>
                    </div>


                    <div class="slider-items slider-width-col4 products-grid block-content">

                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Bunch of Assorted Gerberas in a Glass Vase" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Bunch of Assorted Gerberas in a Glass Vase" src="{{asset('assets/uploads/sites/26/2017/07/product4-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="new-label new-top-right">
                                            Sale            </div>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="30">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=30"  data-product-id="30"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="30"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Bunch of Assorted Gerberas in a Glass Vase"> Bunch of Assorted Gerberas in a Glass Vase </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:0%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="30"><span class="woocs_price_code" data-product-id="30"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>85.99</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>49.99</span></ins></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="30"
                                                   href='/creta/?add-to-cart=30'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Glass Vase of Yellow Roses" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Glass Vase of Yellow Roses" src="{{asset('assets/uploads/sites/26/2017/07/product9-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="new-label new-top-right">
                                            Sale            </div>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="99">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=99"  data-product-id="99"
                                                       data-product-type="grouped" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="99"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Glass Vase of Yellow Roses"> Glass Vase of Yellow Roses </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:90%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="99"><span class="woocs_price_code" data-product-id="99"><span class="woocs_price_code" data-product-id="99"><span class="woocs_price_code" data-product-id="99"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>11.99</span> &ndash; <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>37.00</span></span></span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="button btn-cart" title='View products'
                                                   onClick='window.location.assign("#")' >
                                                    <span>View products </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Pink Roses for your Loved Ones" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Pink Roses for your Loved Ones" src="{{asset('assets/uploads/sites/26/2017/07/product10-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="96">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=96"  data-product-id="96"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="96"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Pink Roses for your Loved Ones"> Pink Roses for your Loved Ones </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:100%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="96"><span class="woocs_price_code" data-product-id="96"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>19.99</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="96"
                                                   href='/creta/?add-to-cart=96'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Beautiful Basket of Gerberas & Roses" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Beautiful Basket of Gerberas & Roses" src="{{asset('assets/uploads/sites/26/2017/07/product11-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="87">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=87"  data-product-id="87"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="87"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Beautiful Basket of Gerberas & Roses"> Beautiful Basket of Gerberas & Roses </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:80%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="87"><span class="woocs_price_code" data-product-id="87"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>11.99</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="87"
                                                   href='/creta/?add-to-cart=87'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="item">
                            <div class="item-inner">
                                <div class="item-img">
                                    <div class="item-img-info">
                                        <a href="#" title="Basket of Roses with Dairymilk Silk" class="product-image">
                                            <figure class="img-responsive">
                                                <img alt="Basket of Roses with Dairymilk Silk" src="{{asset('assets/uploads/sites/26/2017/07/product12-277x366.jpg')}}"">
                                            </figure>
                                        </a>
                                        <div class="box-hover">
                                            <ul class="add-to-links">
                                                <li>
                                                    <a class="yith-wcqv-button link-quickview" href="#"
                                                       data-product_id="113">Quick View</a>
                                                </li>
                                                <li>
                                                    <a href="/creta/?add_to_wishlist=113"  data-product-id="113"
                                                       data-product-type="simple" class="add_to_wishlist link-wishlist"                                >Add to Wishlist</a>
                                                </li>
                                                <li>

                                                    <a href="#" class="compare link-compare add_to_compare" data-product_id="113"
                                                    >Add to Compare</a>

                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info">
                                    <div class="info-inner">
                                        <div class="item-title"><a href="#"
                                                                   title="Basket of Roses with Dairymilk Silk"> Basket of Roses with Dairymilk Silk </a>
                                        </div>
                                        <div class="item-content">
                                            <div class="rating">
                                                <div class="ratings">
                                                    <div class="rating-box">
                                                        <div style="width:0%" class="rating"> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-price">
                                                <div class="price-box">
                                                    <span class="woocs_price_code" data-product-id="113"><span class="woocs_price_code" data-product-id="113"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>77.99</span></span></span>                  </div>
                                            </div>
                                            <div class="action">
                                                <a class="single_add_to_cart_button add_to_cart_button  product_type_simple ajax_add_to_cart button btn-cart" title='Add to cart' data-quantity="1" data-product_id="113"
                                                   href='/creta/?add-to-cart=113'>
                                                    <span>Add to cart </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>






                    </div>
                </div>
            </div>
        </div>
    </div>
</div>