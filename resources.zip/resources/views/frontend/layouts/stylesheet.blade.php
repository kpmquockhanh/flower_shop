<link rel="shortcut icon" type="image/x-icon" href="{{asset('img/logo2.png')}}" />
<script type='text/javascript' src='{{asset('assets/includes/js/jquery/jquery.js')}}'></script>
    @include('frontend.preloader.preloader')
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {{--<link rel="profile" href="http://gmpg.org/xfn/11">--}}
    {{--<link rel="pingback" href="#">--}}
    {{--<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>--}}
    <style>
        .wishlist_table .add_to_cart, a.add_to_wishlist.button.alt {
            border-radius: 16px; -moz-border-radius: 16px; -webkit-border-radius: 16px;
        }
    </style>

    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/contact-form-7/includes/css/styles.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/magik-catalog-mode/assets/css/mgkcmo_style.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/magik-infinite-scroller/assets/css/mgkisr_style.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/magik-wooajax-search/assets/css/mgkwooas_style.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/woo-variation-swatches/assets/css/frontend.min.css')}}' type='text/css' media='all' />--}}
    {{--<link rel='stylesheet' href='{{asset('assets/plugins/woo-variation-swatches/assets/css/wvs-theme-override.min.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/woo-variation-swatches/assets/css/frontend-tooltip.min.css')}}' type='text/css' media='all' />--}}
    {{--<link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-compare/assets/css/colorbox.css')}}' type='text/css' media='all' />--}}
    {{--<link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-compare/assets/css/widget.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/plugins/woocommerce/assets/css/prettyPhoto.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-wishlist/assets/css/style.css')}}' type='text/css' media='all' />--}}
{{--    <link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-wishlist/assets/css/font-awesome.min.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/themes/creta/css/flexslider.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/themes/creta/css/jquery.bxslider.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/themes/creta/css/magikautosearch.css')}}' type='text/css' media='all' />--}}
{{--<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/blogs.css')}}' type='text/css' media='all' />--}}
<style id='yith-quick-view-inline-css' type='text/css'>
    #yith-quick-view-modal .yith-wcqv-main{background:#ffffff;}
</style>


<link rel='stylesheet' href='{{asset('assets/plugins/woocommerce/assets/css/woocommerce-layout.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/plugins/woocommerce/assets/css/woocommerce-smallscreen.css')}}' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' href='{{asset('assets/plugins/woocommerce/assets/css/woocommerce.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/includes/css/dashicons.min.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/plugins/yith-woocommerce-quick-view/assets/css/yith-quick-view.min.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/bootstrap.min.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/css/font-awesome.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/css/simple-line-icons.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/css/owl.carousel.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/css/owl.theme.css')}}' type='text/css' media='all' />

<link rel='stylesheet' href='{{asset('assets/themes/creta/style.css')}}' type='text/css' media='all' />

<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/revslider.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/style.min.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/mgk_menu.min.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/themes/creta/skins/default/jquery.mobile-menu.css')}}' type='text/css' media='all' />
<link rel='stylesheet' href='{{asset('assets/plugins/mailchimp-for-wp/assets/css/form-basic.min.css')}}' type='text/css' media='all' />

