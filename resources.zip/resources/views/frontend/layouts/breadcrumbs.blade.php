<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <ul>
                    <li><a class="home" href="">Home</a><span> ⁄ </span></li>
                    <li><strong>Occasion</strong><span> ⁄ </span></li>
                </ul>
            </div>
            <!--col-xs-12-->
        </div>
        <!--row-->
    </div>
    <!--container-->
</div>