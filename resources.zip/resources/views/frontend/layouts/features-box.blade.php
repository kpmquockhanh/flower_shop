<div class="our-features-box">
    <div class="container">

        <div class="row">
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box first"> <span class="fa fa-truck"></span>
                    <div class="content">
                        <h3>MIỄN PHÍ GIAO HÀNG TOÀN QUỐC</h3>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"> <span class="fa fa-headphones"></span>
                    <div class="content">
                        <h3>CHĂM SÓC KHÁCH HÀNG 24/7</h3>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box"> <span class="fa fa-share"></span>
                    <div class="content">
                        <h3>ĐỔI TRẢ DỄ DÀNG</h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-12 col-sm-6">
                <div class="feature-box last"> <span class="fa fa-phone"></span>
                    <div class="content">
                        <h3>Dường đây nóng  +(84) 989-594-241</h3>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>